* run the pipeline when user rmakes a draft release, and make a normal release after that
    * think about it mb there is a better way

